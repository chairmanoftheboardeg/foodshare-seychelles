Place logo.png and tng-logo.png in this folder.
