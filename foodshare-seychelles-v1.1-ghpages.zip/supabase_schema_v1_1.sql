
-- FoodShare Seychelles: Supabase SQL schema (v1.1)
-- Paste into Supabase SQL Editor and run.
-- Notes:
-- 1) This script assumes the Supabase "auth" schema exists (default).
-- 2) It enables Row Level Security (RLS) and implements role-based access.
-- 3) All user-facing submissions are linked to auth.uid().

begin;

-- Extensions
create extension if not exists pgcrypto;

-- ================
-- Core reference data
-- ================
create table if not exists public.roles (
  id        int primary key,
  name      text not null unique
);

insert into public.roles (id, name) values
  (1, 'Admin'),
  (2, 'Staff'),
  (3, 'Driver'),
  (4, 'Community')
on conflict (id) do nothing;

-- ================
-- Profiles
-- ================
create table if not exists public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  role_id     int not null references public.roles(id) default 4,
  full_name   text,
  email       text,
  phone       text,
  avatar_url  text,
  is_online   boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_profiles_updated_at on public.profiles;
create trigger trg_profiles_updated_at
before update on public.profiles
for each row execute function public.set_updated_at();

-- Prevent non-admins from changing role_id on their own profile
create or replace function public.prevent_role_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if exists (select 1 from public.profiles p where p.id = auth.uid() and p.role_id = 1) then
    return new; -- admin may change roles
  end if;

  if new.role_id <> old.role_id then
    raise exception 'role_id cannot be changed by non-admin users';
  end if;

  return new;
end;
$$;

drop trigger if exists trg_profiles_prevent_role_change on public.profiles;
create trigger trg_profiles_prevent_role_change
before update on public.profiles
for each row execute function public.prevent_role_change();

-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, role_id, full_name, email, phone, avatar_url)
  values (
    new.id,
    4,
    coalesce(new.raw_user_meta_data->>'full_name', ''),
    new.email,
    coalesce(new.raw_user_meta_data->>'phone', ''),
    coalesce(new.raw_user_meta_data->>'avatar_url', '')
  )
  on conflict (id) do update
  set email = excluded.email;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Helper role checks
create or replace function public.is_admin()
returns boolean
language sql
stable
as $$
  select exists(
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role_id = 1
  );
$$;

create or replace function public.is_staff()
returns boolean
language sql
stable
as $$
  select exists(
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role_id in (2,3)
  );
$$;

-- ================
-- Settings (singleton)
-- ================
create table if not exists public.settings (
  id           int primary key,
  announcement text,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

drop trigger if exists trg_settings_updated_at on public.settings;
create trigger trg_settings_updated_at
before update on public.settings
for each row execute function public.set_updated_at();

insert into public.settings (id, announcement) values (1, null)
on conflict (id) do nothing;

-- ================
-- Food listings (inventory)
-- ================
create table if not exists public.food_listings (
  id           uuid primary key default gen_random_uuid(),
  title        text not null,
  description  text,
  category     text,
  quantity     text,
  expiry_date  date,
  island       text,
  urgency      text,
  pickup_notes text,
  is_available boolean not null default true,
  created_by   uuid references public.profiles(id),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

drop trigger if exists trg_food_listings_updated_at on public.food_listings;
create trigger trg_food_listings_updated_at
before update on public.food_listings
for each row execute function public.set_updated_at();

-- ================
-- Donations
-- ================
create table if not exists public.donations (
  id                 uuid primary key default gen_random_uuid(),
  user_id            uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  donor_name         text not null,
  email              text not null,
  phone              text not null,
  island             text,
  food_type          text,
  estimated_quantity text,
  expiry_date        date,
  storage_condition  text,
  description        text,
  pickup_lat         numeric,
  pickup_lng         numeric,
  pickup_address     text,
  pickup_timeframe   text,
  status             text not null default 'New',
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);

drop trigger if exists trg_donations_updated_at on public.donations;
create trigger trg_donations_updated_at
before update on public.donations
for each row execute function public.set_updated_at();

-- ================
-- Claims (self-pickup / transport)
-- ================
create table if not exists public.claims (
  id                 uuid primary key default gen_random_uuid(),
  user_id            uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  listing_id         uuid references public.food_listings(id),
  request_type       text not null check (request_type in ('Transport','SelfPickup')),
  full_name          text not null,
  email              text not null,
  phone              text not null,
  geo_lat            numeric,
  geo_lng            numeric,
  delivery_address   text,
  delivery_time_start timestamptz,
  delivery_time_end   timestamptz,
  signature_accepted boolean not null default false,
  status             text not null default 'New',
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);

drop trigger if exists trg_claims_updated_at on public.claims;
create trigger trg_claims_updated_at
before update on public.claims
for each row execute function public.set_updated_at();

-- ================
-- Volunteer applications
-- ================
create table if not exists public.volunteer_applications (
  id                    uuid primary key default gen_random_uuid(),
  user_id               uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  full_name             text not null,
  email                 text not null,
  phone                 text not null,
  linkedin_url          text not null,
  residency_status      text not null,
  island                text,
  weekly_availability   text,
  transport_availability boolean,
  interest_areas        text[] not null default '{}'::text[],
  motivation            text,
  status                text not null default 'New',
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);

drop trigger if exists trg_vol_apps_updated_at on public.volunteer_applications;
create trigger trg_vol_apps_updated_at
before update on public.volunteer_applications
for each row execute function public.set_updated_at();

-- ================
-- Inquiries (general assistance / contact)
-- ================
create table if not exists public.inquiries (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  full_name  text not null,
  email      text not null,
  phone      text,
  subject    text,
  message    text not null,
  status     text not null default 'New',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

drop trigger if exists trg_inquiries_updated_at on public.inquiries;
create trigger trg_inquiries_updated_at
before update on public.inquiries
for each row execute function public.set_updated_at();

-- ================
-- Notifications
-- ================
create table if not exists public.notifications (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  title      text not null,
  message    text not null,
  type       text not null default 'Info',
  is_read    boolean not null default false,
  created_at timestamptz not null default now()
);

-- ================
-- Tasks (staff operations)
-- ================
create table if not exists public.tasks (
  id            uuid primary key default gen_random_uuid(),
  ref_table     text,
  ref_id        uuid,
  task_type     text,
  title         text not null,
  description   text,
  location_notes text,
  due_at        timestamptz,
  assigned_to   uuid references public.profiles(id),
  status        text not null default 'New',
  staff_notes   text,
  created_by    uuid not null default auth.uid() references public.profiles(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

drop trigger if exists trg_tasks_updated_at on public.tasks;
create trigger trg_tasks_updated_at
before update on public.tasks
for each row execute function public.set_updated_at();

-- ================
-- Audit logs
-- ================
create table if not exists public.audit_logs (
  id         bigserial primary key,
  ref_table  text not null,
  action     text not null,
  record_id  uuid,
  actor_id   uuid,
  details    jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.audit_log_trigger()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_action text;
  v_record uuid;
  v_details jsonb;
begin
  if (tg_op = 'INSERT') then
    v_action := 'INSERT';
    v_record := new.id;
    v_details := to_jsonb(new);
  elsif (tg_op = 'UPDATE') then
    v_action := 'UPDATE';
    v_record := new.id;
    v_details := jsonb_build_object('old', to_jsonb(old), 'new', to_jsonb(new));
  elsif (tg_op = 'DELETE') then
    v_action := 'DELETE';
    v_record := old.id;
    v_details := to_jsonb(old);
  end if;

  insert into public.audit_logs(ref_table, action, record_id, actor_id, details)
  values (tg_table_name, v_action, v_record, auth.uid(), v_details);

  if (tg_op = 'DELETE') then
    return old;
  end if;
  return new;
end;
$$;

-- Apply audit triggers on core tables
drop trigger if exists trg_audit_food_listings on public.food_listings;
create trigger trg_audit_food_listings
after insert or update or delete on public.food_listings
for each row execute function public.audit_log_trigger();

drop trigger if exists trg_audit_donations on public.donations;
create trigger trg_audit_donations
after insert or update or delete on public.donations
for each row execute function public.audit_log_trigger();

drop trigger if exists trg_audit_claims on public.claims;
create trigger trg_audit_claims
after insert or update or delete on public.claims
for each row execute function public.audit_log_trigger();

drop trigger if exists trg_audit_volunteer_applications on public.volunteer_applications;
create trigger trg_audit_volunteer_applications
after insert or update or delete on public.volunteer_applications
for each row execute function public.audit_log_trigger();

drop trigger if exists trg_audit_inquiries on public.inquiries;
create trigger trg_audit_inquiries
after insert or update or delete on public.inquiries
for each row execute function public.audit_log_trigger();

drop trigger if exists trg_audit_tasks on public.tasks;
create trigger trg_audit_tasks
after insert or update or delete on public.tasks
for each row execute function public.audit_log_trigger();


-- ================
-- Notifications automation (admins + user status changes)
-- ================
create or replace function public.notify_admins_new_submission()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  title_text text;
  msg_text text;
begin
  title_text := 'New submission';
  msg_text := 'A new record was submitted in table: ' || tg_table_name || ' (id: ' || new.id || ').';

  insert into public.notifications (user_id, title, message, type)
  select p.id, title_text, msg_text, 'AdminAlert'
  from public.profiles p
  where p.role_id = 1;

  return new;
end;
$$;

create or replace function public.notify_user_on_status_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  title_text text;
  msg_text text;
begin
  if tg_op <> 'UPDATE' then
    return new;
  end if;

  if new.status is distinct from old.status then
    title_text := initcap(tg_table_name) || ' status updated';
    msg_text := 'Your ' || tg_table_name || ' (' || new.id || ') status is now: ' || new.status || '.';
    insert into public.notifications (user_id, title, message, type)
    values (new.user_id, title_text, msg_text, 'StatusUpdate');
  end if;

  return new;
end;
$$;

-- Triggers for admin alerts on insert
drop trigger if exists trg_notify_admins_claims on public.claims;
create trigger trg_notify_admins_claims
after insert on public.claims
for each row execute function public.notify_admins_new_submission();

drop trigger if exists trg_notify_admins_donations on public.donations;
create trigger trg_notify_admins_donations
after insert on public.donations
for each row execute function public.notify_admins_new_submission();

drop trigger if exists trg_notify_admins_volunteer_applications on public.volunteer_applications;
create trigger trg_notify_admins_volunteer_applications
after insert on public.volunteer_applications
for each row execute function public.notify_admins_new_submission();

drop trigger if exists trg_notify_admins_inquiries on public.inquiries;
create trigger trg_notify_admins_inquiries
after insert on public.inquiries
for each row execute function public.notify_admins_new_submission();

-- Triggers for user status change notifications
drop trigger if exists trg_notify_user_claims_status on public.claims;
create trigger trg_notify_user_claims_status
after update on public.claims
for each row execute function public.notify_user_on_status_change();

drop trigger if exists trg_notify_user_donations_status on public.donations;
create trigger trg_notify_user_donations_status
after update on public.donations
for each row execute function public.notify_user_on_status_change();

drop trigger if exists trg_notify_user_vol_apps_status on public.volunteer_applications;
create trigger trg_notify_user_vol_apps_status
after update on public.volunteer_applications
for each row execute function public.notify_user_on_status_change();

drop trigger if exists trg_notify_user_inquiries_status on public.inquiries;
create trigger trg_notify_user_inquiries_status
after update on public.inquiries
for each row execute function public.notify_user_on_status_change();

-- ================
-- Public impact RPC (safe aggregates)
-- ================
create or replace function public.get_impact_public()
returns table (
  staff_count bigint,
  donations_count bigint,
  claims_count bigint,
  apps_in_review bigint,
  meals_estimated bigint,
  kg_rescued numeric,
  carbon_offset_kg_co2e numeric
)
language plpgsql
security definer
set search_path = public
as $$
begin
  staff_count := (select count(*) from public.profiles where role_id in (1,2,3));
  donations_count := (select count(*) from public.donations);
  claims_count := (select count(*) from public.claims);
  apps_in_review := (select count(*) from public.volunteer_applications where status ilike '%review%');

  -- Placeholder calculations; replace with your own models if desired.
  meals_estimated := donations_count * 10;     -- rough placeholder
  kg_rescued := donations_count * 5;           -- rough placeholder
  carbon_offset_kg_co2e := (kg_rescued * 2.5); -- rough placeholder

  return next;
end;
$$;

grant execute on function public.get_impact_public() to anon, authenticated;

-- ================
-- RLS
-- ================
alter table public.profiles enable row level security;
alter table public.settings enable row level security;
alter table public.food_listings enable row level security;
alter table public.donations enable row level security;
alter table public.claims enable row level security;
alter table public.volunteer_applications enable row level security;
alter table public.inquiries enable row level security;
alter table public.notifications enable row level security;
alter table public.tasks enable row level security;
alter table public.audit_logs enable row level security;

-- PROFILES policies
drop policy if exists profiles_select_own on public.profiles;
create policy profiles_select_own on public.profiles
for select
using (id = auth.uid());

drop policy if exists profiles_update_own on public.profiles;
create policy profiles_update_own on public.profiles
for update
using (id = auth.uid())
with check (id = auth.uid());

drop policy if exists profiles_admin_all on public.profiles;
create policy profiles_admin_all on public.profiles
for all
using (public.is_admin())
with check (public.is_admin());

-- SETTINGS policies
drop policy if exists settings_select_public on public.settings;
create policy settings_select_public on public.settings
for select
using (true);

drop policy if exists settings_admin_write on public.settings;
create policy settings_admin_write on public.settings
for update
using (public.is_admin())
with check (public.is_admin());

-- FOOD LISTINGS policies
drop policy if exists listings_select_public_available on public.food_listings;
create policy listings_select_public_available on public.food_listings
for select
using (is_available = true);

drop policy if exists listings_admin_all on public.food_listings;
create policy listings_admin_all on public.food_listings
for all
using (public.is_admin())
with check (public.is_admin());

-- DONATIONS policies
drop policy if exists donations_insert_own on public.donations;
create policy donations_insert_own on public.donations
for insert
with check (user_id = auth.uid());

drop policy if exists donations_select_own on public.donations;
create policy donations_select_own on public.donations
for select
using (user_id = auth.uid());

drop policy if exists donations_admin_all on public.donations;
create policy donations_admin_all on public.donations
for all
using (public.is_admin())
with check (public.is_admin());

-- CLAIMS policies
drop policy if exists claims_insert_own on public.claims;
create policy claims_insert_own on public.claims
for insert
with check (user_id = auth.uid());

drop policy if exists claims_select_own on public.claims;
create policy claims_select_own on public.claims
for select
using (user_id = auth.uid());

drop policy if exists claims_admin_all on public.claims;
create policy claims_admin_all on public.claims
for all
using (public.is_admin())
with check (public.is_admin());

-- VOLUNTEER APPS policies
drop policy if exists apps_insert_own on public.volunteer_applications;
create policy apps_insert_own on public.volunteer_applications
for insert
with check (user_id = auth.uid());

drop policy if exists apps_select_own on public.volunteer_applications;
create policy apps_select_own on public.volunteer_applications
for select
using (user_id = auth.uid());

drop policy if exists apps_admin_all on public.volunteer_applications;
create policy apps_admin_all on public.volunteer_applications
for all
using (public.is_admin())
with check (public.is_admin());

-- INQUIRIES policies
drop policy if exists inquiries_insert_own on public.inquiries;
create policy inquiries_insert_own on public.inquiries
for insert
with check (user_id = auth.uid());

drop policy if exists inquiries_select_own on public.inquiries;
create policy inquiries_select_own on public.inquiries
for select
using (user_id = auth.uid());

drop policy if exists inquiries_admin_all on public.inquiries;
create policy inquiries_admin_all on public.inquiries
for all
using (public.is_admin())
with check (public.is_admin());

-- NOTIFICATIONS policies
drop policy if exists notifications_select_own on public.notifications;
create policy notifications_select_own on public.notifications
for select
using (user_id = auth.uid());

drop policy if exists notifications_update_own on public.notifications;
create policy notifications_update_own on public.notifications
for update
using (user_id = auth.uid())
with check (user_id = auth.uid());

drop policy if exists notifications_insert_own on public.notifications;
create policy notifications_insert_own on public.notifications
for insert
with check (user_id = auth.uid());

drop policy if exists notifications_admin_all on public.notifications;
create policy notifications_admin_all on public.notifications
for all
using (public.is_admin())
with check (public.is_admin());

-- TASKS policies
drop policy if exists tasks_select_assigned on public.tasks;
create policy tasks_select_assigned on public.tasks
for select
using (assigned_to = auth.uid());

drop policy if exists tasks_update_assigned on public.tasks;
create policy tasks_update_assigned on public.tasks
for update
using (assigned_to = auth.uid())
with check (assigned_to = auth.uid());

drop policy if exists tasks_admin_all on public.tasks;
create policy tasks_admin_all on public.tasks
for all
using (public.is_admin())
with check (public.is_admin());

-- AUDIT policies
drop policy if exists audit_admin_select on public.audit_logs;
create policy audit_admin_select on public.audit_logs
for select
using (public.is_admin());

commit;
