-- Promote a user to Admin (role_id=1)
-- Replace EMAIL_HERE with the email used to sign up.
update public.profiles
set role_id = 1
where lower(email) = lower('EMAIL_HERE');
